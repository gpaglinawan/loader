README

This is a mule project template for a mule process API - single app (no rabbit)

Consult:
https://wfs-confluence.wellsfargo.com:8443/pages/viewpage.action?pageId=388104273

section: API 3-Layer-Architecture
sub-section: Process API

Purpose of the PROCESS API:

To expose a business-oriented interface definition with endpoints expressed in plain English and business-friendly terms.

. The process layer steps (no rabbit)

1. expose business operations (English friendly) via RAML & example JSON files
request &/or response format is canonical

Note: slightly different steps based on REST verb: GET & DELETE (manipulate canonical objects on the response only; PUT & POST : both on request & response.
2. instantiate canonical object
3. apply business logic (when required) on the object
4. invoke request-impl to service layer.
5. (optional) request-impl implements retry strategy in case mule runtimes are disseminated across
the network. (build-in the template already)

6. Receives canon JSON response canon, process response according to http.status code from process-layer
7. pass through the response (still in canonical format) and http.status code as received from sys-api layer.

Handling exceptions:

> if exception is throw in the process layer (this one), implement standard exception strategy and returns 
client specific JSON error object.

> if exception has bubbled up from system-layer (i.e. JSON canon error object), just bubble up the error canon object to the exp-api.
the canon error object to client specific error object (must match with RAML examples).

Global endpoints:
listener: use sharedListener from domain
request-config: 1 only pointing to the sys-api listener  

RAML: endpoints (aka methods) = resource + verb

REST style: plain English style (recommended, to be discussed with business analysts) 
getLegalEntity?entityId=123 (GET) or use syntax /legalEntity/{entityId} (GET)  which is a more technical API syntax style and also acceptable since
the business services are never exposed directly to end-consumers.

request-impl.xml: as many flows as there are endpoints in RAML (or flow stubs in api.xml)
Each request-impl.xml flow is a request to the system API corresponding endpoint.

helpers.xml for helper flows
Your utils functions.

workers.xml for orchestration logic and mapping to proper adapter request formats (payloads should be canonical ideally but variants may happen).

workflow is as follow:

exp-api -> api.xml -> workers.xml (orchestration and request formatting) -> request-impl -> sys-api -> request-impl -> workers.xml (response processing) 
-> back to exp-api (due to synchronous nature of the call).
