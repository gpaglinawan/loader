package com.wellsfargo.utils;

import java.util.Arrays;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class DetermineCustomerType implements Callable {

	public Object onCall(MuleEventContext eventContext) throws Exception {
		// TODO Auto-generated method stub
		
		String individualEntityLegalTypes[] = {"EMP","EMPBKF","EMPFAM","EMPS20","FOIND","INDIV"};
		String customerType = "";
			if(Arrays.asList(individualEntityLegalTypes).contains(eventContext.getMessage().getInvocationProperty("legalType"))){
				customerType = "INDIVIDL";
			} else{
				customerType = "NON-INDIVIDL";
			}

		return customerType;

	}
}