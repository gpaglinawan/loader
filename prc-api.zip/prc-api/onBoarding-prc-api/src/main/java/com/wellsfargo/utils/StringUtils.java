package com.wellsfargo.utils;

import org.json.JSONObject;
import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.processor.MessageProcessor;

public class StringUtils  implements MessageProcessor{

	@Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		
		String str=event.getMessage().getPayload().toString();
		String replaceStr = str.replaceAll("(\\r\\n|\\n|\\r)", "");
		System.out.println("The replaced string is "+replaceStr);

		JSONObject jsonObj=new JSONObject(replaceStr);
		System.out.println("THE Json Str is"+jsonObj);
		event.getMessage().setPayload(jsonObj);
		return event;
	}
	
	public static void main(String[] args) {
		
String abc="{  \"Response\":{    \"appName\": \"CustomerVerification\" ,    }}";
System.out.println(abc);
		JSONObject jsonObj=new JSONObject(abc);

		//System.out.println(abc.replaceAll("\n", "").replaceAll("\r", ""));
		System.out.println(jsonObj);
		
	}

}
