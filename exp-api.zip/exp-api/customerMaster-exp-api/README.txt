README
----------
<<<<<<< HEAD
This is the mule project for CustomerMaster experience API

Consult:
https://wfs-confluence.wellsfargo.com:8443/pages/viewpage.action?pageId=388104273

section: API 3-Layer-Architecture
sub-section: Experience API

Purpose of the EXPERIENCE API:

. Decouple the client application from the business/process layer, where the process layer manipulates 
canonical model objects and standardized request & response objects for the WHOLE enterprise set of APIs. 

. The client application often is not able to comply to consuming an enterprise process layer 
(sending request and expecting response objects of another format)
The experience layer acts as a translator.

. The experience layer also sanitizes the request payloads submitted to the service (by service
we understand process layer) by performing schema validation on the request data:
data types, ENUMS, object nesting, null objects, required fields...

. The experience layer steps:

1. expose format 'F' via RAML (example JSON files)
2.a. schema validation in RAML (JSON schema files), or
2.b schema validationin code (inside mule flows) when validation may be too complex with 'Validate JSON schema' message processor

3. format request data to canonical serviceRequest (exp-api is JSON-canon-version aware)
4. invoke request-impl to service layer.
5. (optional) request-impl implements retry strategy in case mule runtimes are disseminated across
the network. (build-in the template already)

6. Receives canon JSON response canon, process response according to http.status code from process-layer
7. formats to format 'F' (response)
and return format-F compliant payload to caller (or custom json error object) with adequate http.status code

Handling exceptions:

> if exception is throw in the exp-api, implement standard exception strategy and returns 
client specific JSON error object.

> if exception has bubbled up from process-layer (i.e. JSON canon error object), exp-api will translate
the canon error object to client specific error object (must match with RAML examples).

Global endpoints:
listener: use sharedListener from domain
request-config: 1 only pointing to the service prc-api listener  

RAML: endpoints (aka methods) = resource + verb

REST style: plain English style (recommended, to be discussed with consumers) for experience API: 
getLegalEntity?entityId=123 (GET) instead of /legalEntity/{entityId} (GET)  which is more of a process API syntax style.
To be debated based on who the API audience is.

request-impl.xml: as many flows as there are endpoints in RAML (or flow stubs in api.xml)
Each request-impl.xml flow is a request to the process API corresponding endpoint.

helpers.xml for helper flows
Your utils functions.

workers.xml for orchestration logic and mapping from request format to canon format

workflow is as follow:

client -> api.xml -> workers.xml (orchestration and request formatting) -> request-impl -> prc-api -> request-impl -> workers.xml (response processing) 
-> back to client (due to synchronous nature of the call).
=======

CustomerMaster Experience API
>>>>>>> develop
