import { NgModule } from '@angular/core';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GridModule,ExcelModule } from '@progress/kendo-angular-grid';
import { AppComponent } from './app.component';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { FormsModule } from '@angular/forms';
import { HttpModule, RequestOptions } from "@angular/http";
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import {MdButtonModule, MdCheckboxModule, MdSelectModule, MdInputModule,MdToolbarModule, MdIconModule} from '@angular/material';
import { Ng2DeviceDetectorModule } from 'ng2-device-detector';
import { PopupModule } from '@progress/kendo-angular-popup';
import {SwitchModule} from '@progress/kendo-angular-inputs';
import {CustomRequestOptions} from './customrequestoptions';

@NgModule({
   bootstrap:    [AppComponent],
   declarations: [AppComponent],
   imports:      [BrowserModule, FormsModule,BrowserAnimationsModule,MdIconModule,PopupModule, SwitchModule,
     GridModule,LayoutModule,NoopAnimationsModule, MdSelectModule, MdInputModule, MdToolbarModule,
    HttpModule,DropDownsModule, MdButtonModule, ExcelModule,Ng2DeviceDetectorModule.forRoot()],
    providers: [
         { provide: RequestOptions, useClass: CustomRequestOptions }
     ]


})
export class AppModule {
}
