import { ChangeDetectorRef, Compiler, Component, NgModule, OnDestroy, OnInit,ViewEncapsulation } from '@angular/core';
//import { customers } from './customers';
import {
  ExcelModule,
  GridComponent,
  GridDataResult,
  PageChangeEvent,
  SelectableSettings
} from '@progress/kendo-angular-grid';
import { DomSanitizer,SafeHtml  } from '@angular/platform-browser';
import { MdIconRegistry } from '@angular/material';
import { Headers, Http } from "@angular/http";
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { environment } from 'environments/environment';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';
import { orderBy, process, State, SortDescriptor, filterBy} from '@progress/kendo-data-query';
import { AnonymousSubscription } from "rxjs/Subscription";
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { Ng2DeviceService } from 'ng2-device-detector';
import { parseDate } from '@telerik/kendo-intl';
import { formatDate } from '@telerik/kendo-intl';

//import { Compiler } from '@angular/compiler';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['app.component.scss'],
  encapsulation: ViewEncapsulation.None


})
export class AppComponent implements OnInit, OnDestroy {
  gridDataResult: GridDataResult;
  private toggleText: string = "Show";
  private show: string = '';
  private display: boolean = false;
  skip = 0;
  loading = true;
  scHeight: any = (window.innerHeight - 200);

  pageSize = Math.ceil(window.innerHeight / 35);
   checked: boolean = false;
  public data: any[];
  gridData: any[] = this.data;
  environmentName = environment.envName;
  environmentHost = environment.enviHost1;

  environmentHost2 = environment.enviHost2;
  environmentPort = environment.enviPort;
  public sort: SortDescriptor[] = [];
  showDLEACompleted:boolean = false;


  public group: any[] = [{
    field: 'cifName1'
  }];
  selectedValue = null;
  selectedRelValue = null;
  selectedRelEcn = null;
  selectedState = null;
  mainPartyFlag = null;
  relPartyFlag = null;
  newRelPartyFlag = null;
  hasRelatedParty = false;
  client: any = null;
  deviceInfo = null;
  wcisList: any[] = [];
  buttonShown = null;
  relRecord = null;
  mainPartyJSON = {};
  releatedParties = [];
  selectedRelParties = [];
  relParties = [];
  accountNumbers: any = null;
  selectedWcisValue: any = null;
  hasNoWebserviceError: boolean = true;
  isCompatibleBrowser: boolean = true;
  sanitizer: DomSanitizer = null;
  isComplete: any = 'doNotShow';

  state: State = {
    skip: 0,
    take: 5,

    // Initial filter descriptor
    filter: {
      logic: "and",
      filters: [{ field: "cifName1", operator: "contains", value: "DT" }]
    }
  };
  public allData = (): Observable<any> => {
    return this.http
           .get("http://" + this.environmentHost + ":" + this.environmentPort + "/getCustomertarget")
           .map(response => (<GridDataResult>{
               data: response.json(),
               total: parseInt(response['@odata.count'], 1000)
           }));

    //return this.http
    //  .get("http://" + this.environmentHost + ":" + this.environmentPort + "/getCustomertarget")


      //.map(response => response.json());
    //   .map(response => (<GridDataResult>{
    //     data: response.value
    //   })
    // );
  }

  // public allData = (): Observable<any> => {
  //   return this.http
  //     .get("https://" + this.environmentHost + "/getCustomertarget?tsp=" + Math.random())
  //     .map(response => response.json())
  //     .map(response => (<GridDataResult>{
  //       data: response.value
  //     }));
  // }
  private timerSubscription: AnonymousSubscription;
  private postsSubscription: AnonymousSubscription;
  private checkboxOnly: boolean = false
  private mode: string = "single";
  private selectableSettings: SelectableSettings;

  constructor(iconRegistry: MdIconRegistry, sanitizer: DomSanitizer, private http: Http,
    private cd: ChangeDetectorRef, private runtimeCompiler: Compiler, private deviceService: Ng2DeviceService
    ) {
    runtimeCompiler.clearCache();
    iconRegistry.addSvgIcon(
      'save-svg',
      sanitizer.bypassSecurityTrustResourceUrl('assets/ic_save_black_24px.svg'));
    this.hasRelatedParty = false;
    //this.allData = this.allData.bind(this);
    //alert(Math.ceil(window.innerHeight/35));
    this.deviceInfo = this.deviceService.getDeviceInfo();
    this.sanitizer = sanitizer;
    debugger;
    // this.setSelectableSettings();
  }

  public createValue() {
    console.log('test');
  }

  // angular.module('app', []).controller('myCtrl', ['$scope', function($scope)
  // {
  //     alert('xxx');
  //     $scope.count = 0;
  //     $scope.myFunc = function() {
  //         $scope.count++;
  //
  //     };
  // }]);

  public myFunc()
  {
    alert('zzzzzzzzzzzzzzzzzzz');
  }



  public exportToExcel2() {
    // let headersAdditional: Headers = new Headers();

    // alert('Report request has been sent... 3.1.18');
    var url = "http://112.32.4.159:8090/getReport?CustomerReport.xlsx";
var strWindowFeatures = "";
var rptwindow = window.open(url,"Customer Report",strWindowFeatures);
return false;



      // this.http.post("http://112.32.4.159:8090/getReport","",headersAdditional).subscribe((res) => {
      //      // this.refreshData();
      //      ;
      //   }, (err) => {
      //
      //   });
      //
  }


//Argument of type '{ responseType: "blob"; }' is not assignable to parameter of type 'RequestOptionsArgs'
//Types of property 'responseType' are incompatible.  Type '"blob"' is not assignable to type 'ResponseContentType'.

  // public exportToExcel3()  {
  //   return this.http.get    ("http://112.32.4.159:8090/getReport",
  //     {responseType: 'blob'}).map(blob => {
  //       var urlCreator = window.URL;
  //       return this._sanitizer.bypassSecurityTrustUrl(urlCreator.createObjectURL(blob));
  //                                         }
  //                               )
  // }

  public async exportToExcel()
  {
    //var url = "http://112.32.4.159:8090/getReport?CustomerReport.xlsx";
    var url = "https://"+this.environmentHost+"/getReport?CustomerReport.xlsx";
    var strWindowFeatures = "";
    var rptwindow = window.open(url,"Customer Report",strWindowFeatures);
    return false;
  }

  public async  forceGenerate() {
    //var url = "http://112.32.4.159:8090/getReport?forceGenerate=yes";
    var url = "https://"+this.environmentHost+"/getReport?forceGenerate=yes";
    var strWindowFeatures = "";
    var rptwindow = window.open(url,"Customer Report",strWindowFeatures);
    return false;

}



  public selectWcisId(wcisId, ecn) {
    //alert("ecn "+ecn);
    this.mainPartyJSON["ecn"] = ecn;
    this.mainPartyJSON["icisClientId"] = wcisId.value;
    this.selectedValue = wcisId.value;
    this.mainPartyFlag = ecn;

    //alert('this.hasRelatedParty '+this.hasRelatedParty);

    if (this.hasRelatedParty) {

      let y = this.wcisList;
      //alert(' this.wcisList.length '+ this.wcisList.length);
      if (y.length > 0) {
        for (let t in y) {
          //alert('test');
          let wcisClientId = y[t].value;

          let z = this.client.customerRelationships;
          //alert('z '+z);
          for (let d in z) {
            //  alert('d '+d);
            if (this.client.customerRelationships[d].wcisResponselst != null
              || this.client.customerRelationships[d].wcisResponselst.length > 0) {

              let s = this.client.customerRelationships[d].wcisResponselst;
              //alert('s.length '+s.length);
              for (let x in s) {
                //alert('x '+x);
                let icis = this.client.customerRelationships[d].wcisResponselst[x].wcisId;
                if (icis == wcisClientId) {
                  //alert(true);
                  //this.mainPartyFlag = ecn;
                  this.buttonShown = 'true' + ecn;
                }
              }

            }
          }

        }
      }
      else {
        this.buttonShown = 'true' + ecn;
      }

    }

    //  alert('this.selectedValue '+this.selectedValue);
    this.selectedValue == 'new';
    !this.hasRelatedParty;
    //alert(ecn.toString());
    //"true".concat(ecn.toString());
    //alert("true".concat(ecn.toString()));
    this.buttonShown = "t" + (ecn.toString());
    if (this.hasRPErrors(this.client.customerRelationships)) {
      this.buttonShown = "false";
    }
    //this.buttonShown ="";
    //alert('this.buttonShown '+this.buttonShown);
    /*
        if (this.selectedValue == 'new' || !this.hasRelatedParty){

          this.buttonShown = 'true'+ecn;
        }
      else{
        this.checkmatched(wcisId, ecn);
        }
*/

    //  alert('test');
    //console.log("wcis" );
  }

  public ngOnDestroy(): void {
    if (this.postsSubscription) {
      this.postsSubscription.unsubscribe();
    }
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }
  }

  public hasRPCleared(ecn) {
    //alert(ecn);
    let isClear: boolean = false;
    for (var i = 0; i < this.gridData.length; i++) {
      var currJson = this.gridData[i];
      if (ecn == currJson['ecn']) {
        //  alert('ecn '+ecn);
        //debugger;
        //  alert('currJson ecn '+currJson['ecn']);
        var custRelationships = currJson['customerRelationships'];
        if (custRelationships.length > 0) {
          for (var j = 0; j < custRelationships.length; j++) {
            var relationShip = custRelationships[j];
            var wcisResponseList = relationShip['wcisResponselst'];
            //alert(relationShip.customerStatusNarrative.includes('Mismatch'));
            if ((typeof wcisResponseList !== "undefined") &&
              wcisResponseList.length > 1) {
              //alert('false');

              return isClear;
              //break;
            }
            if ((relationShip.customerStatusNarrative.includes('Mismatch')
              || relationShip.customerStatusNarrative.includes('Error'))) {
              //alert('');
              return isClear;
            }
            //alert('relationShip(wcisResponselst) '+relationShip('wcisResponselst'));
          }
        }

        //alert('custRelationships[wcisResponselst] '+custRelationships['wcisResponselst']);
      }
    }

    //alert('hasRPCleared '+ecn);
    isClear = true;
    //alert('isClear '+isClear);
    return isClear;

  }

  public selectRelWcisId(wcisId, relecn, ecn) {
    //alert("wcisId "+wcisId.value);
    //alert("this.gridData "+JSON.stringify(this.gridData));
    //alert(this.mainPartyJSON["icisClientId"]);

    //alert("this.gridData "+this.gridData);
    this.removeRelatedParties(relecn, wcisId.value);
    this.buttonShown = '';
    var releatedPartiJSON = {}
    releatedPartiJSON["icisClientId"] = wcisId.value;
    releatedPartiJSON["ecn"] = relecn;

    this.releatedParties.push(releatedPartiJSON);

    //alert("this.relParties.length "+this.relParties.length);
    if (this.releatedParties.length == this.relParties.length) {
      //alert('match '+true);
      this.buttonShown = 'true' + ecn;

    }
    this.selectedRelEcn = relecn;


    this.selectedRelValue = wcisId.value;
    //alert("this.selectedRelValue "+this.selectedRelValue);
    this.relPartyFlag = relecn;
    this.newRelPartyFlag = ecn;
    this.wcisList.push(wcisId);
    //if (this.mainPartyFlag == ecn){

    this.buttonShown = 'true' + ecn;


  }

  ngOnInit(): void {
    //alert("ngOnInit");
    //    this.http.get("./data.json")
    // const headers = new Headers();
    // headers.append('Access-Control-Allow-Origin', '*');
    // headers.append('Access-Control-Allow-Credentials', 'true');

    this.hasRelatedParty = false;
    //this.http.get("http://112.32.4.99:9090/getCustomertarget")
    //this.http.get('assets/data.json')
    //alert("http://"+this.environmentHost+":"+this.environmentPort+"/getCustomerstaging");
    //this.http.get("http://112.32.4.150:9090/getCustomertarget")
    //this.http.get("http://localhost:9090/getCustomerstaging")


    //this.http.get("http://"+this.environmentHost+":"+this.environmentPort+"/getCustomerstaging")

    //this.refreshData();
    //alert('load');
    if (this.deviceInfo.browser != 'ie') {
      this.isCompatibleBrowser = false;
      this.loading = false;
      return;
    }
    else
    {
      debugger;

//alert(" OnInit http://" + this.environmentHost + ':' + this.environmentPort + "/getCustomertarget")

      //this.http.get("http://" + this.environmentHost + ':' + this.environmentPort + "/getCustomertarget")
//production
    this.http.get("https://" + this.environmentHost + "/getCustomertarget")
        //this.http.get("http://localhost:9090/getCustomertarget")
        .subscribe((gridData) => {
          this.loading = false;
          //alert(gridData.status);
          setTimeout(() => {
            //this.gridData = gridData.json();
            this.gridData = orderBy(gridData.json(), [{ field: "extras.dateCreated", dir: "desc" },{ field: "cifName1", dir: "asc" }]);
            this.convertStringToDate(this.gridData);
          }, 1000);
          //  this.subscribeData();
          //  this.gridDataResult = process(this.gridData, null);

          return true;
        },
        error => {
          //this.loading = false;
          //this.hasNoWebserviceError = false;
          //alert('error '+ Observable.throw(error));
          //return Observable.throw(error);
          //this.http.get("http://" + this.environmentHost2 + ':' + this.environmentPort + "/getCustomertarget")
        //prod
        this.http.get("https://" + this.environmentHost2 +"/getCustomertarget")
            //this.http.get("http://localhost:9090/getCustomertarget")
            .subscribe((gridData) => {
              this.loading = false;
              //alert(gridData.status);
              setTimeout(() => {
                //this.gridData = gridData.json();
                this.gridData = orderBy(gridData.json(), [{ field: "extras.dateCreated", dir: "desc" },{ field: "cifName1", dir: "asc" }])

              }, 1000);
              //  this.subscribeData();
              //  this.gridDataResult = process(this.gridData, null);
              return true;
            },
            error => {
              this.loading = false;
              this.hasNoWebserviceError = false;

            });
        });
      if (this.deviceInfo.browser != 'ie') {
        this.isCompatibleBrowser = false;
        return;
      }

      this.refreshData();
    }
  }

  //console.log("wcis" );

  //public updateWcisId(ecn: string){
  public updateWcisId(ecn: string) {
    //alert("ecn "+ecn);
    //alert("relatedEcn "+relatedEcn);
  //  var _this = this;
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');

    this.mainPartyJSON["customerRelationships"] = [];
    let payload = JSON.stringify(this.mainPartyJSON);
    //let url = 'http://localhost:9090/updateCustomer';
    //let url = 'http://wuvra00a0263:9090/updateCustomer';
    //let url = "http://" + this.environmentHost + ":" + this.environmentPort + "/updateCustomer";
    let url = "https://" + this.environmentHost + "/updateCustomer";
    console.log('payload ' + payload);
    //alert('payload '+payload);
	 this.selectedValue=null;
	this.buttonShown = false;
    let headersAdditional: Headers = new Headers();

    headersAdditional.append('Cache-control', 'no-cache');
    headersAdditional.append('Cache-control', 'no-store');
    headersAdditional.append('Expires', '0');
    headersAdditional.append('Pragma', 'no-cache');
    headersAdditional.append('Access-Control-Allow-Origin', '*');
    headersAdditional.append('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS');

    this.http
      .post(url, payload, { headers: headersAdditional }).subscribe((res) => {
            this.buttonShown = false;
			this.selectedValue=null;
              this.refreshData();
      }, (err) => {
      });

    //this.refreshData();
    this.cd.detectChanges();

  }

  /**  private loadItems(): void {
        this.gridData = {
            data: this.items.slice(this.skip, this.skip + this.pageSize),
            total: this.items.length
        };
      //  alert(this.gridData.data[0]);
    }**/

  public getStatusRowFormat(status) {
    //alert(status);
    var legendclass = "";
    if (status == undefined)
      return;
    if (status.trim() == 'Submitted to Cornerstone') {
      legendclass += "multiWcisRow";
    }
    else if (status.trim().includes("DLEA Error")) {
      legendclass += "selectRow";
    }
    else if (status.trim() == "DLEA Completed" || status.trim() == "DLEA Created") {
      legendclass += "submittedRow";
    }
    else if (status.trim() == "MULTIPLE WIICS") {
      legendclass += "multiWcisRow";
    }
    //alert(legendclass);
    return legendclass;
  }

  public clientGridChange(clientGrid, selection) {
    //alert("selection.index "+selection.index);
    //debugger;
    //alert("this.client "+clientGrid);
    //let selectedClient = clientGrid.data.data[selection.index];
    let selectedClient = selection.selectedRows[0].dataItem;
    //alert(selectedClient);
    this.client = selectedClient;
    //alert(selectedClient.customerRelationships.length);
    //  alert("this.client "+this.client);
    //this.hasRelatedParty = selectedClient.customerRelationships.length > 0;

    let y = this.client.customerRelationships;
    for (let d in y) {
      //alert(this.client.customerRelationships[d].ecn);
      this.relParties.push(this.client.customerRelationships[d].ecn);
    }
  }

  public getSelectedWcisValue() {
    alert('test');
    return this;
  }

  public relationshipGridChange(relationshipGrid, selection) {
    // alert('relationshipGridChange ');
    //alert('selection.index '+selection.index);
    let selectedRecord = relationshipGrid.data[selection.index];
    this.relRecord = selectedRecord;
    //alert('this.relParties '+this.relParties);
    if (this.relParties.includes(this.relRecord.ecn)) {

    }
  }

  public showOnlyIfRelationshipsExist(dataItem: any, index: number): boolean {
    return dataItem.customerRelationships.length > 0;
  }

  public hasRPErrors(customerRelationships: any): boolean {
    let hasError: boolean = false;

    for (var i = 0; i < customerRelationships.length; i++) {
      let relationship = customerRelationships[i];
      //alert(relationship.customerStatusNarrative);
      if (relationship.customerStatusNarrative.includes('Mismatch')) {
        //  alert(relationship.customerStatusNarrative);
        hasError = true;
        break;
      }
    }
    return hasError;
  }

  public getStatusAlignment(status) {

    if (status.includes('DLEA Error'))
      return 'text-align:left';
    else
      return 'text-align:center';

  }

  //}
  protected pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    //  this.loadItems();
  }

  private checkmatched(wcisId, ecn): void {
    let y = this.wcisList;
    //alert(' this.wcisList.length '+ this.wcisList.length);
    if (y.length > 0) {
      for (let t in y) {
        let wcisClientId = y[t].value;

        let z = this.client.customerRelationships;
        //alert('z '+z);
        for (let d in z) {
          //alert('d '+d);
          if (this.client.customerRelationships[d].wcisResponselst != null
            || this.client.customerRelationships[d].wcisResponselst.length > 0) {


            let s = this.client.customerRelationships[d].wcisResponselst;
            //alert('s.length '+s.length);
            for (let x in s) {
              //alert('x '+x);
              let icis = this.client.customerRelationships[d].wcisResponselst[x].wcisId;
              if (icis == wcisClientId) {
                //alert(true);
                //this.mainPartyFlag = ecn;
                this.buttonShown = 'true' + ecn;
              }
            }

          }
        }

      }
    }
  }

  private removeRelatedParties(relecn: string, wcis: string) {

    let s = this.releatedParties;

    for (let t in s) {
      var t1 = parseInt(t);
      //alert('relecn '+relecn);
      var releatedPartiJSON = this.releatedParties[t1];
      //alert("relecn"+relecn.includes("new"));
      if (wcis.includes("new")) {
        //alert("empty");
        this.releatedParties = [];
      }
      if (releatedPartiJSON["ecn"] == relecn) {
        //alert("pop");
        this.releatedParties.splice(t1, 1);

      }
      //alert('this.releatedParties.length '+this.releatedParties.length);
    }

  }

  private refreshData(): void {

    //var _this = this;
	if(this.selectedValue!=null || this.selectedRelEcn!=null)
		 return;

    //  alert('refresh');
    //this.gridData = null;

    //this.postsSubscription = this.http.get("http://" + this.environmentHost + ":" + this.environmentPort + "/getCustomertarget?show="+this.isComplete)
  //prod
  this.postsSubscription = this.http.get("https://" + this.environmentHost + "/getCustomertarget")
      .subscribe((gridData) => {
        setTimeout(() => {
          //this.gridData = gridData.json();
          this.gridData =  orderBy(gridData.json(), [{ field: "extras.dateCreated", dir: "desc" },{ field: "cifName1", dir: "asc" }])
          this.convertStringToDate(this.gridData);
          this.buttonShown = false;
        }, 1000);
        this.subscribeData();
      },
      error => {
        return Observable.throw(error);
      });

  }

  private subscribeData(): void {
    this.timerSubscription = Observable.timer(15000).first().subscribe(() => this.refreshData());

  }

  private updateRelWcisId(parentEcn: string, ecn: string) {
    //alert("ecn "+ecn);
    //alert("relatedEcn "+relatedEcn);

    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    this.mainPartyJSON['ecn'] = parentEcn;
    this.mainPartyJSON['icisClientId'] = null;
    this.mainPartyJSON['customerRelationships'] = this.releatedParties;
    let payload = JSON.stringify(this.mainPartyJSON);
	this.selectedRelEcn=null;
    //const url = 'http://' + this.environmentHost + ':' + this.environmentPort + '/updateCustomer';
    const url = 'https://' + this.environmentHost + '/updateCustomer';
    //alert('payload '+payload);
    //alert('url '+url);
    //var headersAdditional = Headers;

    //headersAdditional = < Headers > Headers().headers();
    const headersAdditional: Headers = new Headers({ 'Access-Control-Allow-Origin': '*' });
    headersAdditional.append('Content-Type', 'application/json');
    headersAdditional.append('Cache-control', 'no-cache');
    headersAdditional.append('Cache-control', 'no-store');
    headersAdditional.append('Expires', '0');
    headersAdditional.append('Pragma', 'no-cache');
    headersAdditional.append('Access-Control-Allow-Credentials', 'true');
    headersAdditional.append('Access-Control-Allow-Headers', 'Content-Type');
    headersAdditional.append('Access-Control-Allow-Methods', 'OPTIONS');

    this.http
      .post(url, payload, { headers: headersAdditional }).subscribe((res) => {
        this.refreshData();
      }, (err) => {
      });

    //this.refreshData();
    this.cd.detectChanges();

  }
  public sortChange(sort: SortDescriptor[]): void {
       this.sort = sort;
      // this.gridData = orderBy(gridData.json(), [{ field: "cifName1", dir: "asc" }])
       //alert('sort');
       //this.loadProducts();
   }

   public formatDate(myStringDate){

      //return parseDate("2000/11/12","yyyy/MM/dd");
      var msec= Date.parse(myStringDate);
      return new Date(msec);

   }

   public onToggle(t): void {
       var s = t.ecn;
       this.display = !this.display;
       this.show = 'show'+s;
       this.accountNumbers = null;
       //this.accountNumbers = "svvbvbdb"
       let l = t.customerAccounts;

       for (let e in l)
       {
          let accountNo = t.customerAccounts[e].accountNumber;
          //alert(accountNo);
          //let linebreak = document.createElement("br");
          //alert(linebreak);
          if (this.accountNumbers != null){
            this.accountNumbers = '<br>'+this.accountNumbers + accountNo+'<br/>';
          }
          else{
            this.accountNumbers = '<br>'+accountNo+'<br/>';
          }
       }
      // this.accountNumbers = escapedHtmlProperty(this.accountNumbers);
       //this.toggleText = this.show ? "Hide" : "Show";
   }

   public get escapedHtmlProperty() : SafeHtml  {
        return this.sanitizer.bypassSecurityTrustHtml(this.accountNumbers);
     }

     public getAccounts(d){
        //  return 'test';
         let acctNo:any = '';
         let l = d.customerAccounts;
         for (let e in l)
         {
            acctNo = acctNo+d.customerAccounts[e].accountNumber+'<br/>';
        //    //alert(accountNo);
        //    //let linebreak = document.createElement("br");
        //    //alert(linebreak);
        //
         }
         return acctNo;

     }
     public convertStringToDate(customer){
          //debugger;
          for (var i in customer){

            var createdDate = customer[i]['extras']['dateCreated'];
            var updatedDate = customer[i]['extras']['dateUpdated'];

            customer[i]['extras']['dateCreated'] = new Date(createdDate.replace(/-/g, '\/'));
            customer[i]['extras']['dateUpdated'] = new Date(updatedDate.replace(/-/g, '\/'));

            //if (null != createdDate){

            //}
          }

     }
     public showCompleted(event){
       //alert(event);
       this.isComplete = 'doNotShow';
       if (event)
          this.isComplete = 'showComplete';

        //this.http.get("http://" + this.environmentHost2 + ':' + this.environmentPort + "/getCustomertarget")
         this.http.get("https://" + this.environmentHost + "/getCustomertarget")
         //this.http.get("http://localhost:9090/getCustomertarget")
         .subscribe((gridData) => {
           this.loading = false;
           //alert(gridData.status);
           setTimeout(() => {
             //this.gridData = gridData.json();
             this.gridData =
             //filterBy(gridData.json(), [{ field: "extras.dateCreated", dir: "desc" },{ field: "cifName1", dir: "asc" }])

             filterBy(gridData.json(), {
                logic: 'and',
                filters: [
                      { field: "customerStatusNarrative", operator: "eq", value: "ERROR", ignoreCase: true }
                ]
              })

           }, 1000);
           //  this.subscribeData();
           //  this.gridDataResult = process(this.gridData, null);
           return true;
         },
         error => {
           //this.loading = false;
           //this.hasNoWebserviceError = false;
           //alert('error '+ Observable.throw(error));
           //return Observable.throw(error);
           //this.http.get("http://" + this.environmentHost2 + ':' + this.environmentPort + "/getCustomertarget")
          //prod
          this.http.get("https://" + this.environmentHost2 + "/getCustomertarget")
             //this.http.get("http://localhost:9090/getCustomertarget")
             .subscribe((gridData) => {
               this.loading = false;
               //alert(gridData.status);
               setTimeout(() => {
                 //this.gridData = gridData.json();
                 this.gridData = filterBy(gridData.json(), {
                    logic: 'and',
                    filters: [
                          { field: "customerStatusNarrative", operator: "eq", value: "ERROR", ignoreCase: true }
                    ]
                  })
                  //orderBy(gridData.json(), [{ field: "extras.dateCreated", dir: "desc" },{ field: "cifName1", dir: "asc" }])

               }, 1000);
               //  this.subscribeData();
               //  this.gridDataResult = process(this.gridData, null);
               return true;
             },
             error => {
               this.loading = false;
               this.hasNoWebserviceError = false;

             });
         });


     }

  // public onExcelExport(e: any): void {
  //  debugger;
  //
  //  const rows = e.workbook.sheets[0].rows;
  // // e.workbook.sheets[1] = new Object();
  //  // align multi header
  //  rows[0].cells[2].hAlign = 'center';
  //  //rows[1] = new Object();
  //  // set alternating row color
  //  let altIdx = 0;
  //  // e.workbook.sheets[1].rows=new Array();
  //  // e.workbook.sheets[1].rows[0]=new Object();
  //  // e.workbook.sheets[1].rows[0].type = 'header'
  //  rows.forEach((row) => {
  //   // e.workbook.sheets[1].rows[0]=new Object();
  //   // e.workbook.sheets[1].rows[0].type = 'header'
  //      if (row.type === 'data') {
  //
  //           //e.workbook.sheets[1].rows[altIdx]=new Object();
  //          //e.workbook.sheets[1].rows[altIdx]=new Object();
  //          if (altIdx % 2 !== 0) {
  //              let celIdx = 0;
  //             e.workbook.sheets[1].rows[altIdx].cells = new Array();
  //              row.cells.forEach((cell) => {
  //
  //               //  e.workbook.sheets[1].rows[altIdx].cells[celIdx] = new Object();
  //               //  e.workbook.sheets[1].rows[altIdx].cells[celIdx].value = cell.value;
  //                  cell.background = '#aabbcc';
  //               //   celIdx++;
  //                  //e.workbook.sheets[1].rows[altIdx].cells[]
  //                  //cell.value = 'Gareth';
  //              });
  //          }
  //          altIdx++;
  //      }
  //  });
  //  }


}
