export const environment = {
  production: false,
  envName: 'qa1',
  //enviHost1: 'wsvra98a0724.wellsfargo.com',
  //enviHost2: 'wsvra98a0724.wellsfargo.com',
  enviHost1: 'cornerstonesit.wellsfargo.com',
  enviHost2: 'cornerstonesit.wellsfargo.com',  
  enviPort: '9090'
};
