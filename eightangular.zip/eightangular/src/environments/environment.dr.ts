export const environment = {
  production: true,
  envName: 'dr',
  enviHost1: 'wrvra98a0724.wellsfargo.com',
  enviHost2: 'wrvra98a0724.wellsfargo.com',
  enviPort: '9090'
};
