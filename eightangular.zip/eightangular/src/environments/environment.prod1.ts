export const environment = {
  production: true,
  envName: 'prod1',
  enviHost1: 'wpvra99a0724',
  enviHost2: 'wpvra99a0724',
  enviPort: '9090'
};
