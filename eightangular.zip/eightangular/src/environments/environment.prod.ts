export const environment = {
  production: true,
  envName: 'prod',
  enviHost1: 'wpvra98a0724',
  enviHost2: 'wpvra98a0724',
  enviPort: '9090'
};
