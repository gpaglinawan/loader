export const environment = {
  production: false,
  envName: 'prods',
  enviHost1: 'cornerstone.wellsfargo.com',
  enviHost2: 'cornerstone.wellsfargo.com',
  //enviHost1: 'wsvra98a0724',
  //enviHost2: 'wsvra98a0724',
  //enviHost:'112.32.4.141',
  enviPort: '9090'
};
