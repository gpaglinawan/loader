export const environment = {
  production: false,
  envName: 'uats',
  enviHost1: 'cornerstoneuat.wellsfargo.com',
  enviHost2: 'cornerstoneuat.wellsfargo.com',
  //enviHost1: 'wsvra98a0724',
  //enviHost2: 'wsvra98a0724',
  //enviHost:'112.32.4.141',
  enviPort: '9090'
};
