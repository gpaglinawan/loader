export const environment = {
  production: true,
  envName: 'prod',
  enviHost1: 'wuvra00a0263',
  enviHost2: 'wuvra00a0263',
  enviPort: '9090'
};
